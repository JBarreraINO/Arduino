## pc_debug: bluepad32 for Linux

Useful while adding new gamepads and/or testing new features that don't neceseraly
require an ESP32.

Make sure that libusb-1.0-dev is installed and do:

```
$ make

# And run it with sudo:
$ sudo ./bluepad32
