## sixaxispairer

More info in [docs][docs_pairer] folder, but basically it is a tool to let you pair your
DS3 gamepad with ESP32.

```
$ make sixaxispairer
$ sudo ./sixaxispairer XX:XX:XX:XX:XX:XX
```

[docs_pairer]: https://gitlab.com/ricardoquesada/bluepad32/-/blob/master/docs/pair_ds3.md
