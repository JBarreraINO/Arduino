# Bluepad32 for Arduino library

Here goes the Bluepad32 for Arduino "public" files.

Users should only call the APIs exposed by the files found here.
Users should not call the "C" library directly: it might change without further notice.

These files are placed here temporarly. They might be moved to its own repo (?).